<!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="active treeview">
              <ul class="treeview-menu">
                <li><a href="<?php echo site_url('avesteach_c/index'); ?>"><i class="fa fa-circle-o"></i> Home</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="<?php echo site_url('avesteach_c/student'); ?>"><i class="fa fa-circle-o"></i> Student</a>
            </li>
            <li class="treeview">
              <a href="<?php echo site_url('avesteach_c/article'); ?>"><i class="fa fa-circle-o"></i> Article</a>
            </li>
              
      </aside>
